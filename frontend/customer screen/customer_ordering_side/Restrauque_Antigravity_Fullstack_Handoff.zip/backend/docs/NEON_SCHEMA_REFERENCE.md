# Neon Schema Reference for Customer Ordering and Feedback

## Database context
Previously inspected context:
- project label: `resro_intelligence`
- branch: `production`
- database: `neondb`
- schema: `public`

Reconfirm current project/branch/database before migrations. This document is a handoff summary; the backend engineer must verify exact current columns and status enums in code/database before relying on any assumption. Do not add or modify tables from this document without review.

## Entity relationships and purpose

### Restaurant/QR context
- `restaurants`: `id`, `name`, `legal_name`, `email`, `phone`, `address`, `city`, `state`, `country`, `timezone`, `status`, `created_at`, `updated_at`, `owner_id`.
- `branches`: `id`, `restaurant_id`, `name`, `address`, `city`, `state`, `country`, `phone`, `timezone`, `status`, `created_at`, `updated_at`.
- `restaurant_tables`: `id`, `branch_id`, `table_number`, `capacity`, `status`, `is_active`, `created_at`, `updated_at`.
- `qr_codes`: `id`, `table_id`, `code`, `qr_type`, `is_active`, `created_at`, `updated_at`.
Relationships: restaurants have branches; branch owns table; QR references table. Verify FK and query path on actual schema. `restaurants` does not currently confirm branding fields such as logo URL, hero URL, colors, or font.

### Catalog/menu
- `categories`: `id`, `restaurant_id`, `name`, `description`, `display_order`, `is_active`, timestamps.
- `menus`: `id`, `restaurant_id`, `name`, `description`, `is_active`, timestamps.
- `menu_products`: table exists; exact column schema still needs explicit verification before using.
- `products`: `id`, `restaurant_id`, `category_id`, `name`, `description`, `price`, `image_url`, `display_order`, `is_available`, `is_active`, timestamps.
- `product_variants`: `id`, `product_id`, `name`, `price`, `display_order`, `is_available`, `is_active`, timestamps.
- `product_addons`: `id`, `product_id`, `name`, `price`, `is_available`, `is_active`, `display_order`, timestamps.
Do not assume product inventory, calories, ingredients, allergens, vegetarian flag, category images, reviews, preparation time, or stock count. Only expose these if an independently verified table/API field exists.

### Customer/auth
- `customers`: `id`, `name`, `phone`, `status`, `first_visit_at`, `last_visit_at`, timestamps.
- `otp_verifications`: contains `id`, `phone`, `otp_code`, `purpose`, `expires_at`, `verified_at`, `attempts`, `max_attempts`, `status`, `created_at`. `otp_code` is sensitive and must never be returned to the browser.
- `customer_sessions`: contains `id`, `customer_id`, `session_token_hash`, `expires_at`, `last_used_at`, `revoked_at`, `status`, `created_at`. Never expose session token hashes.

### Orders
- `orders`: `id`, `restaurant_id`, `branch_id`, nullable `table_id`, `customer_id`, `order_number`, `order_type`, `status`, `subtotal`, `discount_amount`, `tax_amount`, `total_amount`, `notes`, `ordered_at`, nullable `completed_at`, created/updated timestamps, idempotency fields.
- `order_items`: `id`, `order_id`, `product_id`, nullable `variant_id`, `product_name`, nullable `variant_name`, `quantity`, `unit_price`, `total_price`, `special_instructions`, `created_at`.
- `order_item_addons`: `id`, `order_item_id`, nullable `product_addon_id`, `addon_name`, `quantity`, `unit_price`, `total_price`, `created_at`.
- `order_status_history`: `id`, `order_id`, `status`, `changed_at`, `notes`, `created_at`.
Use `order_items` snapshot names/prices for historical receipts. `orders.status` is not payment status. Authorize customer by authentication and order ownership.

### Coupons/payments
- `coupons`: `id`, `restaurant_id`, `code`, `name`, `description`, `discount_type`, `discount_value`, `minimum_order_amount`, `maximum_discount_amount`, `usage_limit`, `usage_count`, `valid_from`, `valid_until`, `is_active`, timestamps.
- `order_coupons`: `id`, `order_id`, `coupon_id`, `coupon_code`, `discount_type`, `discount_value`, `discount_amount`, `created_at`.
- `payments`: `id`, `order_id`, `amount`, `payment_method`, `status`, `transaction_reference`, `paid_at`, timestamps.
- `payment_transactions`: `id`, `payment_id`, `provider`, `transaction_id`, `provider_transaction_id`, `amount`, `currency`, `status`, `response_code`, `response_message`, `initiated_at`, `completed_at`, timestamps.
Verify real payment methods/provider. Keep transaction metadata private unless explicitly customer-safe.

### Feedback
- `feedback`: `id`, `restaurant_id`, `branch_id`, `order_id`, `customer_id`, nullable `rating` (check 1–5), nullable `comment`, `feedback_type`, `status`, `submitted_at`, `created_at`, `updated_at`.
- `feedback_aspects`: `id`, `feedback_id`, nullable `product_id`, `aspect`, `sentiment`, nullable `aspect_value`, nullable `confidence`, `created_at`, `updated_at`. `sentiment` is required and constrained to `positive`, `negative`, `neutral`, or `mixed`; confidence if present is between 0 and 1.
- `feedback_topics`: `id`, `feedback_id`, `topic`, `sentiment`, nullable `confidence`, timestamps. Sentiment constrained to positive/negative/neutral/mixed.
- `feedback_products` exists, but its exact columns have not been verified in this handoff; describe schema before use.
Relationships observed: feedback references restaurant, branch, order and customer; feedback_aspects references feedback and optionally product. No `order_item_id` or numeric product-rating field was observed on `feedback_aspects`.

## Feedback persistence rule
- Store one overall order rating/comment in `feedback`.
- Store a separate text comment for each ordered product in `feedback_aspects` using `product_id`, `aspect` (stable value agreed by backend, e.g. `item_review`), and `aspect_value`.
- Validate that product ID belongs to that order using `order_items`, not browser input alone.
- Because `sentiment` is required, backend must document an explicit policy before inserting. Use an approved neutral default until a trustworthy sentiment pipeline exists, or use verified backend analysis; never let the UI invent sentiment.
- If product stars need persistence, ask for approval to add schema support (for example a nullable integer rating to the aspects table or a separate item-feedback table) and a migration. No migration is authorized here.

## Migrations and integration
The documents do not authorize migrations or direct DB writes. Backend engineer should propose migrations as reviewed SQL, test on an isolated Neon branch, and obtain explicit approval before applying to production.
