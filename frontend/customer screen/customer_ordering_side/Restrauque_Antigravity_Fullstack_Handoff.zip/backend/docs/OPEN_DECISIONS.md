# Open decisions requiring owner/backend agreement

Do not guess or silently change these decisions.

1. **QR URL format:** use existing route/URL structure if implemented; otherwise agree the public token route. Never expose internal UUIDs unnecessarily.
2. **Authentication:** confirm whether existing backend OTP delivery and verification are implemented, which provider is used, and expected rate limits/session handling.
3. **Order-type and order-status values:** document values from current backend/schema constraints, then map to human-friendly frontend labels.
4. **Payments:** confirm provider, supported methods, whether payment is online, at-counter, or both, and which method is actually implemented. Never fabricate payment completion.
5. **Menu membership:** inspect `menu_products` columns and confirm whether products are served through menus, categories, or both.
6. **Restaurant branding storage:** current restaurant schema lacks confirmed theme attributes. Choose a reviewed theme-config storage/API solution; do not persist only in browser while implying restaurant owners' settings are shared.
7. **Vegetarian indicator:** current known product columns do not contain a vegetarian flag. Confirm another source or leave the UI control out until API support exists.
8. **Promotional coins / loyalty:** the sample reference includes a coins tile, but this handoff does not assume a customer-visible coin balance/API. Include it only if a verified loyalty API supplies the balance and rules; otherwise omit it.
9. **Feedback requiredness:** decide whether overall rating is optional or required; recommendation is optional, with ability to skip.
10. **Product-level numeric stars:** current schema does not persist per-item ratings. Start with per-item text comments only, or approve a new migration/API for per-item ratings.
11. **Feedback sentiment:** required in `feedback_aspects`. Agree a neutral default or backend-only classifier policy.
12. **Duplicate feedback:** decide whether a completed order can receive one submission only or allow updates.
13. **Image hosting:** decide where restaurant logo/product images are stored and returned; frontend should only consume trusted URLs from API.
14. **Theme font allow-list:** choose supported hosted/system fonts and fallback behavior. Do not accept arbitrary uploaded CSS.
15. **Privacy/retention:** confirm feedback moderation, deletion/update policy, and customer support process.
