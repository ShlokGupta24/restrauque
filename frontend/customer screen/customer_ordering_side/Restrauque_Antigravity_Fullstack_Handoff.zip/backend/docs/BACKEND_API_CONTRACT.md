# Backend API Contract — Restrauque Customer Frontend

## Status
This is a proposed contract, not a claim that these endpoints already exist. First inspect the current Python backend routes, services, authentication middleware, and API docs. Reuse existing endpoints where equivalent; document any path or payload adaptation before implementation.

Use a versioned API prefix if the existing backend supports one (for example `/api/v1`). Example paths below are illustrative.

## API operations

### 1. Resolve QR context
`GET /api/v1/customer/qr/{qrToken}`
- Input: opaque QR token/code from scanned link.
- Server validates `qr_codes.is_active`, associated `restaurant_tables.is_active`, table and branch state.
- Response: public restaurant display name, branch display label as needed, table number, restaurant status, supported ordering capabilities, theme config if implemented.
- Never return database connection data, internal auth fields, unnecessary UUIDs, or raw QR token. A non-guessable public identifier may be returned only when necessary by approved routing design.
- Fail safely for invalid/inactive QR, unavailable restaurant/table.

### 2. Read customer menu
`GET /api/v1/customer/restaurants/{restaurantPublicId}/menu`
- Resolve public restaurant context safely; do not trust arbitrary tenant IDs without scope validation.
- Return active categories in `display_order`, active menus and product memberships, active/available products, applicable variants/add-ons.
- Product DTO fields: public product id (if needed for requests), name, description, price, image URL, availability; variants/add-ons only if returned by verified relations.
- `menu_products` schema must be inspected to verify relationships before finalizing menu query.
- Never return internal DB schema or SQL errors to browser.

### 3. Customer authentication
Suggested operations:
- `POST /api/v1/customer/auth/request-otp`
- `POST /api/v1/customer/auth/verify-otp`
The route names are proposals. Existing auth contracts take precedence.
- Validate phone and rate-limit OTP requests/attempts.
- Never return `otp_code` to the browser.
- Persist hashed/session-safe credentials according to existing security design; never expose `session_token_hash`.
- Preserve QR/table context client-side without treating it as proof of authorization.
- Customer must be authenticated before creating an order if this is product policy.

### 4. Create or refresh cart quote
Suggested operation: `POST /api/v1/customer/orders/quote`
- Request includes product/variant/add-on public identifiers, quantities, special instructions, applied coupon code if supported, ordering context.
- Server resolves current availability/prices and calculates subtotal, discount, tax, total.
- Never accept client-supplied final prices as authoritative.
- If the existing architecture does not need a quote endpoint, document the alternative.

### 5. Create order
`POST /api/v1/customer/orders`
- Requires authenticated customer.
- Request includes verified QR/table context reference, order type supported by backend, item/variant/add-on identifiers and quantities, notes, coupon only when supported, idempotency key.
- Server derives customer, restaurant, branch and table context through authorized data; validates availability and all amounts; uses a transaction; persists `orders`, `order_items`, `order_item_addons`, optional `order_coupons`, and appropriate payment records when required by the established payment flow.
- Return `order_number`, user-safe status label/code mapped by DTO, totals, ordered item snapshots, and payment state if available.
- No successful UI state until persistence is confirmed.

### 6. Order status
`GET /api/v1/customer/orders/{orderPublicId}`
`GET /api/v1/customer/orders/{orderPublicId}/status-history`
- Authenticate and verify order belongs to customer.
- Return customer-safe status and history based on `orders` and `order_status_history`.
- Keep payment status separate.
- Do not invent ETA or live map tracking.

### 7. Payments
Use the existing payment integration if it exists. If it does not, document that gap and agree on the provider/payment method before implementation. Do not invent a gateway or accept raw card details in the app.
- `payments` and `payment_transactions` must be updated only by trusted backend/payment webhooks or verified provider responses, not by client claims.
- Never expose provider secrets, raw gateway payloads, or internal transaction IDs unless a customer-facing reference is explicitly approved.

### 8. Submit order feedback
Proposed operation: `POST /api/v1/customer/orders/{orderPublicId}/feedback`
Request example:
```json
{
  "rating": 5,
  "comment": "Overall, the order was excellent.",
  "items": [
    {
      "productId": "public-or-validated-id",
      "comment": "The pasta was creamy and well prepared."
    }
  ]
}
```
- Authenticate customer; verify order ownership and server-confirmed completed status.
- Derive restaurant/branch/order/customer IDs from the authorized order server-side.
- Insert one `feedback` row for overall rating/comment.
- For each non-empty item comment, insert a `feedback_aspects` row linked to the inserted feedback and product (`aspect` should use an agreed stable value such as `item_review`; `aspect_value` stores comment).
- The current `feedback_aspects.sentiment` column is required. Backend owner must choose an explicit policy: approved neutral default until analyzed, or a verified server-side classifier. Do not invent it in the frontend.
- Use a DB transaction, validate the product was part of the order, rate-limit, and prevent accidental duplicate submissions unless edit/review revisions are expressly supported.
- There is no per-item numeric rating column. Do not accept/claim persistent per-product stars without a separate approved migration and API versioning.
- Return saved review summary only after commit.

### 9. Theme configuration
No confirmed logo/hero/color/font columns were found on the inspected `restaurants` schema. Propose and agree one source:
- separate restaurant theme table with versioned migration; or
- backend configuration service; or
- temporary development theme only.
Do not make a frontend-only theme editor appear persisted in production.
Theme DTO may include `logoUrl`, `primaryColor`, `backgroundColor`, `textColor`, `mutedTextColor`, `accentColor`, `fontFamily`, `cardRadius`, and `layoutVariant`; validate against allow-listed colors/fonts/radius/layout tokens rather than arbitrary CSS or script.

## General security and API rules
- Never connect browser directly to Neon.
- Validate everything server-side.
- Parameterize SQL or use the existing ORM.
- Enforce tenant isolation and customer/order ownership.
- Use consistent error response DTOs with safe public messages and trace/correlation ID if available.
- Do not leak table/column names, stack traces, session hashes, OTP values, secrets, or raw gateway responses.
- Use idempotency for order create to protect retry/double taps.
- Document status enums from code/schema; do not invent state transitions.
- Keep mock/dev mode separate from production.
